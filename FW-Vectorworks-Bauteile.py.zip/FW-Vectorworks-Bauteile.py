# -*- coding: utf-8 -*-
# Version 4: Durchgehende Wände mit nativen Öffnungen oder Symbolen mit Wandöffnungsgeometrie.
"""FW – Import in Vectorworks. Stand: Entwurf, Aufmass erforderlich."""
import json
import unicodedata
import vs

PROJECT = json.loads("{\"walls\":[{\"name\":\"AW01 Eingang\",\"axis\":\"H\",\"start\":0,\"end\":8600,\"edge\":0,\"width\":190,\"openings\":[{\"name\":\"Oben_Oeffnung_0\",\"at\":4110,\"span\":900,\"low\":0,\"high\":2110,\"window\":false,\"backup\":[[\"Haustuer_Zarge_Anfang\",[4110,-10,0,25,210,2110],\"#a28b72\"],[\"Haustuer_Zarge_Ende\",[4985,-10,0,25,210,2110],\"#a28b72\"],[\"Haustuer_Zarge_Oben\",[4110,-10,2078,900,210,32],\"#a28b72\"]]}],\"pieces\":[[0,0,0,4110,190,2390],[4110,0,2110,900,190,280],[5010,0,0,3590,190,2390]],\"top\":2390},{\"name\":\"AW02 Wohnfassade\",\"axis\":\"H\",\"start\":0,\"end\":8600,\"edge\":8810,\"width\":190,\"openings\":[{\"name\":\"Unten_Oeffnung_0\",\"at\":1590,\"span\":1200,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Unten_Oeffnung_0_Rahmen_unten\",[1590,8858,900,1200,95,55],\"#a28b72\"],[\"Unten_Oeffnung_0_Rahmen_oben\",[1590,8858,2145,1200,95,55],\"#a28b72\"],[\"Unten_Oeffnung_0_Rahmen_Anfang\",[1590,8858,955,55,95,1190],\"#a28b72\"],[\"Unten_Oeffnung_0_Rahmen_Ende\",[2735,8858,955,55,95,1190],\"#a28b72\"],[\"Unten_Oeffnung_0_Pfosten\",[2163,8858,955,55,95,1190],\"#a28b72\"],[\"Unten_Oeffnung_0_Glas\",[1645,8893,955,1090,25,1190],\"#a5cfda\"]]},{\"name\":\"Unten_Oeffnung_1\",\"at\":5820,\"span\":1200,\"low\":0,\"high\":2200,\"window\":true,\"backup\":[[\"Unten_Oeffnung_1_Rahmen_unten\",[5820,8858,0,1200,95,55],\"#a28b72\"],[\"Unten_Oeffnung_1_Rahmen_oben\",[5820,8858,2145,1200,95,55],\"#a28b72\"],[\"Unten_Oeffnung_1_Rahmen_Anfang\",[5820,8858,55,55,95,2090],\"#a28b72\"],[\"Unten_Oeffnung_1_Rahmen_Ende\",[6965,8858,55,55,95,2090],\"#a28b72\"],[\"Unten_Oeffnung_1_Pfosten\",[6393,8858,55,55,95,2090],\"#a28b72\"],[\"Unten_Oeffnung_1_Glas\",[5875,8893,55,1090,25,2090],\"#a5cfda\"]]}],\"pieces\":[[0,8810,0,1590,190,2390],[1590,8810,0,1200,190,900],[1590,8810,2200,1200,190,190],[2790,8810,0,3030,190,2390],[5820,8810,2200,1200,190,190],[7020,8810,0,1580,190,2390]],\"top\":2390},{\"name\":\"AW03 Zimmerfassade\",\"axis\":\"V\",\"start\":190,\"end\":8810,\"edge\":0,\"width\":190,\"openings\":[{\"name\":\"Links_Oeffnung_0\",\"at\":1030,\"span\":690,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Links_Oeffnung_0_Rahmen_unten\",[48,1030,900,95,690,55],\"#a28b72\"],[\"Links_Oeffnung_0_Rahmen_oben\",[48,1030,2145,95,690,55],\"#a28b72\"],[\"Links_Oeffnung_0_Rahmen_Anfang\",[48,1030,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_0_Rahmen_Ende\",[48,1665,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_0_Glas\",[83,1085,955,25,580,1190],\"#a5cfda\"]]},{\"name\":\"Links_Oeffnung_1\",\"at\":3200,\"span\":1190,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Links_Oeffnung_1_Rahmen_unten\",[48,3200,900,95,1190,55],\"#a28b72\"],[\"Links_Oeffnung_1_Rahmen_oben\",[48,3200,2145,95,1190,55],\"#a28b72\"],[\"Links_Oeffnung_1_Rahmen_Anfang\",[48,3200,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_1_Rahmen_Ende\",[48,4335,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_1_Pfosten\",[48,3768,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_1_Glas\",[83,3255,955,25,1080,1190],\"#a5cfda\"]]},{\"name\":\"Links_Oeffnung_2\",\"at\":6570,\"span\":1190,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Links_Oeffnung_2_Rahmen_unten\",[48,6570,900,95,1190,55],\"#a28b72\"],[\"Links_Oeffnung_2_Rahmen_oben\",[48,6570,2145,95,1190,55],\"#a28b72\"],[\"Links_Oeffnung_2_Rahmen_Anfang\",[48,6570,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_2_Rahmen_Ende\",[48,7705,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_2_Pfosten\",[48,7138,955,95,55,1190],\"#a28b72\"],[\"Links_Oeffnung_2_Glas\",[83,6625,955,25,1080,1190],\"#a5cfda\"]]}],\"pieces\":[[0,190,0,190,840,2390],[0,1030,0,190,690,900],[0,1030,2200,190,690,190],[0,1720,0,190,1480,2390],[0,3200,0,190,1190,900],[0,3200,2200,190,1190,190],[0,4390,0,190,2180,2390],[0,6570,0,190,1190,900],[0,6570,2200,190,1190,190],[0,7760,0,190,1050,2390]],\"top\":2390},{\"name\":\"AW04 Küchenfassade\",\"axis\":\"V\",\"start\":190,\"end\":8810,\"edge\":8410,\"width\":190,\"openings\":[{\"name\":\"Rechts_Oeffnung_0\",\"at\":1980,\"span\":1190,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Rechts_Oeffnung_0_Rahmen_unten\",[8458,1980,900,95,1190,55],\"#a28b72\"],[\"Rechts_Oeffnung_0_Rahmen_oben\",[8458,1980,2145,95,1190,55],\"#a28b72\"],[\"Rechts_Oeffnung_0_Rahmen_Anfang\",[8458,1980,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_0_Rahmen_Ende\",[8458,3115,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_0_Pfosten\",[8458,2548,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_0_Glas\",[8493,2035,955,25,1080,1190],\"#a5cfda\"]]},{\"name\":\"Rechts_Oeffnung_1\",\"at\":5970,\"span\":1190,\"low\":900,\"high\":2200,\"window\":true,\"backup\":[[\"Rechts_Oeffnung_1_Rahmen_unten\",[8458,5970,900,95,1190,55],\"#a28b72\"],[\"Rechts_Oeffnung_1_Rahmen_oben\",[8458,5970,2145,95,1190,55],\"#a28b72\"],[\"Rechts_Oeffnung_1_Rahmen_Anfang\",[8458,5970,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_1_Rahmen_Ende\",[8458,7105,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_1_Pfosten\",[8458,6538,955,95,55,1190],\"#a28b72\"],[\"Rechts_Oeffnung_1_Glas\",[8493,6025,955,25,1080,1190],\"#a5cfda\"]]}],\"pieces\":[[8410,190,0,190,1790,2390],[8410,1980,0,190,1190,900],[8410,1980,2200,190,1190,190],[8410,3170,0,190,2800,2390],[8410,5970,0,190,1190,900],[8410,5970,2200,190,1190,190],[8410,7160,0,190,1650,2390]],\"top\":2390},{\"name\":\"IW01 Bad–Flur\",\"axis\":\"V\",\"start\":190,\"end\":1610,\"edge\":5280,\"width\":120,\"openings\":[{\"name\":\"Bad_Tueroeffnung\",\"at\":190,\"span\":760,\"low\":0,\"high\":2050,\"window\":false,\"backup\":[[\"Bad_Tuer_Zarge_Anfang\",[5270,190,0,140,25,2050],\"#a28b72\"],[\"Bad_Tuer_Zarge_Ende\",[5270,925,0,140,25,2050],\"#a28b72\"],[\"Bad_Tuer_Zarge_Oben\",[5270,190,2018,140,760,32],\"#a28b72\"]]}],\"pieces\":[[5280,190,2050,120,760,340],[5280,950,0,120,660,2390]],\"top\":2390},{\"name\":\"IW02 Bad–Küche\",\"axis\":\"H\",\"start\":5280,\"end\":8410,\"edge\":1610,\"width\":120,\"openings\":[],\"pieces\":[[5280,1610,0,3130,120,2390]],\"top\":2390},{\"name\":\"IW03 Ehemalige Küchentür geschlossen\",\"axis\":\"V\",\"start\":1730,\"end\":4200,\"edge\":5280,\"width\":120,\"openings\":[],\"pieces\":[[5280,1730,0,120,2470,2390]],\"top\":2390},{\"name\":\"IW04 Flur–Wohnen\",\"axis\":\"H\",\"start\":3840,\"end\":5280,\"edge\":4070,\"width\":120,\"openings\":[{\"name\":\"Wohnzimmertuer_Oeffnung\",\"at\":4430,\"span\":790,\"low\":0,\"high\":2050,\"window\":false,\"backup\":[[\"Wohnzimmertuer_Zarge_links\",[4410,4060,0,25,140,2050],\"#a28b72\"],[\"Wohnzimmertuer_Zarge_rechts\",[5215,4060,0,25,140,2050],\"#a28b72\"],[\"Wohnzimmertuer_Zarge_oben\",[4410,4060,2050,830,140,35],\"#a28b72\"]]}],\"pieces\":[[3840,4070,0,550,120,2390],[4390,4070,0,40,120,2390],[4430,4070,2050,790,120,340],[5220,4070,0,60,120,2390]],\"top\":2390},{\"name\":\"IW05 Zimmer unten–Wohnen\",\"axis\":\"V\",\"start\":5280,\"end\":8810,\"edge\":4230,\"width\":160,\"openings\":[{\"name\":\"Zimmer_unten_Tuer\",\"at\":7400,\"span\":790,\"low\":0,\"high\":2050,\"window\":false,\"backup\":[[\"Zimmer_unten_Tuer_Zarge_Anfang\",[4220,7400,0,180,25,2050],\"#a28b72\"],[\"Zimmer_unten_Tuer_Zarge_Ende\",[4220,8165,0,180,25,2050],\"#a28b72\"],[\"Zimmer_unten_Tuer_Zarge_Oben\",[4220,7400,2018,180,790,32],\"#a28b72\"]]}],\"pieces\":[[4230,5280,0,160,2120,2390],[4230,7400,2050,160,790,340],[4230,8190,0,160,620,2390]],\"top\":2390},{\"name\":\"IW06 Zimmer quer unten\",\"axis\":\"H\",\"start\":190,\"end\":4230,\"edge\":5280,\"width\":120,\"openings\":[],\"pieces\":[[190,5280,0,4040,120,2390]],\"top\":2390},{\"name\":\"IW07 Zimmer quer oben\",\"axis\":\"H\",\"start\":190,\"end\":3840,\"edge\":2100,\"width\":120,\"openings\":[],\"pieces\":[[190,2100,0,3650,120,2390]],\"top\":2390},{\"name\":\"IW08 Zimmer Mitte–Flur\",\"axis\":\"V\",\"start\":2220,\"end\":5280,\"edge\":3720,\"width\":120,\"openings\":[{\"name\":\"Zimmer_Mitte_Tuer\",\"at\":3130,\"span\":800,\"low\":0,\"high\":2050,\"window\":false,\"backup\":[[\"Zimmer_Mitte_Tuer_Zarge_Anfang\",[3710,3130,0,140,25,2050],\"#a28b72\"],[\"Zimmer_Mitte_Tuer_Zarge_Ende\",[3710,3905,0,140,25,2050],\"#a28b72\"],[\"Zimmer_Mitte_Tuer_Zarge_Oben\",[3710,3130,2018,140,800,32],\"#a28b72\"]]}],\"pieces\":[[3720,2220,0,120,910,2390],[3720,3130,2050,120,800,340],[3720,3930,0,120,1350,2390]],\"top\":2390},{\"name\":\"IW09 Zimmer oben–Flur\",\"axis\":\"V\",\"start\":1210,\"end\":2100,\"edge\":3720,\"width\":120,\"openings\":[{\"name\":\"Zimmer_oben_Tuer\",\"at\":1240,\"span\":800,\"low\":0,\"high\":2050,\"window\":false,\"backup\":[[\"Zimmer_oben_Tuer_Zarge_Anfang\",[3710,1240,0,140,25,2050],\"#a28b72\"],[\"Zimmer_oben_Tuer_Zarge_Ende\",[3710,2015,0,140,25,2050],\"#a28b72\"],[\"Zimmer_oben_Tuer_Zarge_Oben\",[3710,1240,2018,140,800,32],\"#a28b72\"]]}],\"pieces\":[[3720,1210,0,120,30,2390],[3720,1240,2050,120,800,340],[3720,2040,0,120,60,2390]],\"top\":2390},{\"name\":\"IW10 Eingangsnische längs\",\"axis\":\"V\",\"start\":190,\"end\":1090,\"edge\":3210,\"width\":120,\"openings\":[],\"pieces\":[[3210,190,0,120,900,2390]],\"top\":2390},{\"name\":\"IW11 Eingangsnische quer\",\"axis\":\"H\",\"start\":3210,\"end\":3840,\"edge\":1090,\"width\":120,\"openings\":[],\"pieces\":[[3210,1090,0,630,120,2390]],\"top\":2390}],\"solids\":[[\"Bad\",\"Bad_Boden\",[5400,190,0,3010,1420,18],\"#8f8679\"],[\"Wohnen\",\"Essstuhl_Gestell\",[6090,4720,0,310,300,440],\"#a28b72\"],[\"Wohnen\",\"Essstuhl_Sitz\",[6040,4680,440,420,400,50],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Lehne\",[6040,4680,490,420,50,330],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Gestell\",[6090,5880,0,310,300,440],\"#a28b72\"],[\"Wohnen\",\"Essstuhl_Sitz\",[6040,5840,440,420,400,50],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Lehne\",[6040,6190,490,420,50,330],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Gestell\",[6590,4720,0,310,300,440],\"#a28b72\"],[\"Wohnen\",\"Essstuhl_Sitz\",[6540,4680,440,420,400,50],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Lehne\",[6540,4680,490,420,50,330],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Gestell\",[6590,5880,0,310,300,440],\"#a28b72\"],[\"Wohnen\",\"Essstuhl_Sitz\",[6540,5840,440,420,400,50],\"#d8b693\"],[\"Wohnen\",\"Essstuhl_Lehne\",[6540,6190,490,420,50,330],\"#d8b693\"],[\"Bad\",\"Bad_Wandbelag_Nord\",[5400,190,0,3010,9,2390],\"#d7ccbd\"],[\"Bad\",\"Bad_Wandbelag_Ost\",[8401,190,0,9,1420,2390],\"#547d77\"],[\"Bad\",\"Bad_Wandbelag_Sued\",[5400,1601,0,3010,9,2390],\"#d7ccbd\"],[\"Bad\",\"Bad_Wandbelag_West\",[5400,950,0,9,660,2390],\"#d7ccbd\"],[\"Bad\",\"Bad_geflieste_Vorwand\",[5400,1450,0,2070,160,1080],\"#d7ccbd\"],[\"Bad\",\"Bad_durchgehender_Sims\",[5400,1450,1080,2070,160,25],\"#d7ccbd\"],[\"Bad\",\"Spiegel_Hinterlicht\",[5728,1586,1192,9,12,598],\"#ffdb9f\"],[\"Bad\",\"Spiegel_Hinterlicht\",[6342,1586,1192,9,12,598],\"#ffdb9f\"],[\"Bad\",\"Spiegel_Hinterlicht\",[5728,1586,1191,623,12,9],\"#ffdb9f\"],[\"Bad\",\"Spiegel_Hinterlicht\",[5728,1586,1781,623,12,9],\"#ffdb9f\"],[\"Bad\",\"Badetuchhalter_Befestigung\",[6860,191,1410,18,101,16],\"#727e83\"],[\"Bad\",\"Badetuchhalter_Befestigung\",[7390,191,1410,18,101,16],\"#727e83\"],[\"Bad\",\"Badetuchhalter_Stange\",[6860,278,1410,548,16,16],\"#727e83\"],[\"Bad\",\"Badetuch\",[6940,286,847,380,27,580],\"#b9a982\"],[\"Bad\",\"Spiegel\",[5740,1583,1200,600,20,580],\"#bed4d8\"],[\"Bad\",\"Heizkoerper_links_nach_Eingang\",[6180,210,180,500,95,520],\"#faf9f4\"],[\"Bad\",\"Heizkoerper_Ventil\",[6690,255,580,45,38,45],\"#727e83\"],[\"Bad\",\"Dusche\",[7490,200,0,900,1380,40],\"#faf9f4\"],[\"Bad\",\"Duschglas\",[7470,860,40,21,720,2350],\"#a5cfda\"],[\"Bad\",\"Bodenrinne_an_WC_Wand\",[7660,1465,39,625,45,2],\"#293234\"],[\"Bad\",\"Rinnenabdeckung_bodenbuendig\",[7668,1472,40,609,31,2],\"#727e83\"],[\"Bad\",\"Duschanschluss_hinten_rechts\",[8130,1540,1040,180,65,70],\"#727e83\"],[\"Bad\",\"Duschstange_hinten_rechts\",[8200,1540,1110,33,38,760],\"#727e83\"],[\"Bad\",\"Duschbrause_hinten_rechts\",[8180,1440,1850,73,130,38],\"#727e83\"]],\"slabs\":[[\"Boden · Rohplatte\",\"Boden / Decke\",0,[[0,0],[8600,0],[8600,9000],[0,9000]],[[\"Rohplatte, Bestand – Aufbau offen\",160,\"#c2beb6\"]]],[\"Boden · Wohnen und Küche\",\"Boden / Decke\",14,[[190,190],[5400,190],[5400,1610],[8410,1610],[8410,8810],[190,8810]],[[\"Eiche matt, astig – angenommen\",14,\"#af8357\"]]],[\"Boden · Bad\",\"Boden / Decke\",14,[[5400,190],[8410,190],[8410,1610],[5400,1610]],[[\"Keramische Fliese – angenommen\",8,\"#727b79\"],[\"Kleber – angenommen\",6,\"#bbb6ab\"]]],[\"Decke · Holzverkleidung\",\"Decke\",2465,[[190,190],[8410,190],[8410,8810],[190,8810]],[[\"Unterkonstruktion, Bestand – angenommen\",57,\"#d5c2a4\"],[\"Fichte astig, Schalung – angenommen\",18,\"#cfa679\"]]]],\"lights\":[[\"Küche · Spot 1\",5970,2970,2380,2],[\"Küche · Spot 2\",6910,2970,2380,2],[\"Küche · Spot 3\",7850,2970,2380,2],[\"Flur · Spot 1\",4620,660,2380,2],[\"Flur · Spot 2\",4620,1920,2380,2],[\"Flur · Spot 3\",4620,3220,2380,2],[\"Esstisch · Pendel\",6490,5460,1730,1]],\"symbols\":[[\"Küche\",\"Küchenzeile\",[[\"Küche\",\"Wandzeile_Sockel_buendig\",[6120,2342,15,2290,30,63],\"#939e95\"],[\"Küche\",\"Wandzeile_Kuehlschrank_Anschlussleiste\",[6050,2344,15,70,28,870],\"#939e95\"],[\"Küche\",\"Wandzeile_Arbeitsplatte\",[6120,1740,840,2290,650,45],\"#686762\"],[\"Küche\",\"Wandzeile · Geschirrspüler SMS\",[6160,1754,78,547,605,762],\"#939e95\"],[\"Küche\",\"Wandzeile · Backofen SMS\",[6710,1754,78,547,605,762],\"#939e95\"],[\"Küche\",\"Wandzeile · Schubladen\",[7260,1754,78,547,605,762],\"#939e95\"],[\"Küche\",\"Wandzeile · Schubladen\",[7810,1754,78,547,605,762],\"#939e95\"],[\"Küche\",\"Oberschrank SMS\",[6160,1740,1405,546,350,635],\"#939e95\"],[\"Küche\",\"Oberschrank SMS\",[6710,1740,1405,546,350,635],\"#939e95\"],[\"Küche\",\"Oberschrank SMS\",[7260,1740,1405,546,350,635],\"#939e95\"],[\"Küche\",\"Backofen · Front\",[6711,2360,78,548,24,635],\"#293234\"]]],[\"Küche\",\"Kühl-Gefrierschrank\",[[\"Küche\",\"Kuehlschrank_Passleiste_10cm\",[5400,2400,15,100,35,1995],\"#939e95\"],[\"Küche\",\"Kuehlschrank_Vollgroesse\",[5500,1740,20,550,700,1980],\"#939e95\"],[\"Küche\",\"Kuehlschrank_Front\",[5520,2440,680,510,25,1330],\"#939e95\"],[\"Küche\",\"Gefrierfach_Front\",[5520,2440,50,510,25,610],\"#939e95\"],[\"Küche\",\"Kuehlschrank_Griff\",[5540,2470,780,28,35,280],\"#293234\"],[\"Küche\",\"Gefrierfach_Griff\",[5550,2470,570,200,35,25],\"#293234\"]]],[\"Küche\",\"Halbinsel\",[[\"Küche\",\"Halbinsel_glatte_Wohnfront\",[5400,4170,15,1990,25,885],\"#939e95\"],[\"Küche\",\"Halbinsel_Stirnseite_bis_Boden\",[7380,3567,15,15,628,885],\"#939e95\"],[\"Küche\",\"Halbinsel_Sockel_Bedienseite\",[5410,3580,15,1970,23,123],\"#939e95\"],[\"Küche\",\"Abwaschtuchhalter_Befestigung\",[7394,3720,750,44,16,16],\"#727e83\"],[\"Küche\",\"Abwaschtuchhalter_Befestigung\",[7394,4060,750,44,16,16],\"#727e83\"],[\"Küche\",\"Abwaschtuchhalter_Stange\",[7428,3720,750,15,355,16],\"#727e83\"],[\"Küche\",\"Abwaschtuch\",[7438,3790,498,21,200,260],\"#b9a982\"],[\"Küche\",\"Halbinsel · Spüle und Abfall\",[5580,3550,138,547,610,762],\"#939e95\"],[\"Küche\",\"Halbinsel · Schubladen\",[6130,3550,138,272,610,762],\"#939e95\"],[\"Küche\",\"Halbinsel · Festes Passstück\",[6405,3550,138,22,610,762],\"#939e95\"],[\"Küche\",\"Halbinsel · V-ZUG\",[6430,3550,138,897,610,508],\"#939e95\"],[\"Küche\",\"Kochfeld\",[6500,3625,937,761,501,8],\"#293234\"],[\"Küche\",\"Armatur\",[5840,4070,945,35,35,190],\"#727e83\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5400,3550,900,230,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5400,3621,900,230,19,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5400,3640,900,230,380,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5400,4020,900,230,109,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5400,4129,900,230,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5630,3550,900,450,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5630,3621,900,450,19,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5630,4020,900,450,109,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[5630,4129,900,450,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6080,3550,900,417,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6080,3621,900,417,19,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6080,3640,900,417,380,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6080,4020,900,417,109,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6080,4129,900,417,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6497,3550,900,767,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[6497,4129,900,767,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[7264,3550,900,136,71,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[7264,3621,900,136,19,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[7264,3640,900,136,380,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[7264,4020,900,136,109,45],\"#686762\"],[\"Küche\",\"Halbinsel · Arbeitsplatte\",[7264,4129,900,136,71,45],\"#686762\"],[\"Küche\",\"Spüle · Beckenboden\",[5630,3640,755,450,380,14],\"#727e83\"],[\"Küche\",\"Spüle · Beckenwand\",[5630,3640,755,15,380,190],\"#727e83\"],[\"Küche\",\"Spüle · Beckenwand\",[6065,3640,755,15,380,190],\"#727e83\"],[\"Küche\",\"Spüle · Beckenwand\",[5645,3640,755,420,15,190],\"#727e83\"],[\"Küche\",\"Spüle · Beckenwand\",[5645,4005,755,420,15,190],\"#727e83\"]]],[\"Wohnen\",\"Esstisch\",[[\"Wohnen\",\"Esstisch_Platte\",[5790,5100,720,1400,720,45],\"#d8b693\"],[\"Wohnen\",\"Esstisch_Bein\",[5850,5160,0,55,55,720],\"#a28b72\"],[\"Wohnen\",\"Esstisch_Bein\",[5850,5690,0,55,55,720],\"#a28b72\"],[\"Wohnen\",\"Esstisch_Bein\",[7070,5160,0,55,55,720],\"#a28b72\"],[\"Wohnen\",\"Esstisch_Bein\",[7070,5690,0,55,55,720],\"#a28b72\"]]],[\"Wohnen\",\"Sofa\",[[\"Wohnen\",\"Sofa_Sockel\",[7430,6050,25,880,1930,340],\"#747b64\"],[\"Wohnen\",\"Sofa_Ruecken\",[8120,6050,365,190,1930,470],\"#747b64\"],[\"Wohnen\",\"Sofa_Armlehne\",[7430,6050,365,690,150,230],\"#747b64\"],[\"Wohnen\",\"Sofa_Armlehne\",[7430,7830,365,690,150,230],\"#747b64\"],[\"Wohnen\",\"Sofa_Sitzpolster\",[7450,6210,365,650,790,120],\"#747b64\"],[\"Wohnen\",\"Sofa_Sitzpolster\",[7450,7020,365,650,790,120],\"#747b64\"]]],[\"Wohnen\",\"TV und Sideboard\",[[\"Wohnen\",\"TV_Lowboard\",[4401,6000,145,375,1190,260],\"#b7abc7\"],[\"Wohnen\",\"TV_Bildschirm\",[4498,5978,456,77,1225,708],\"#293234\"],[\"Wohnen\",\"TV_Fuss\",[4451,6172,405,199,837,51],\"#727e83\"]]],[\"Bad\",\"Waschtisch\",[[\"Bad\",\"Waschtisch_Unterschrank\",[5745,999,250,590,451,543],\"#758479\"],[\"Bad\",\"Waschtischplatte\",[5745,979,788,590,471,24],\"#758479\"],[\"Bad\",\"Waschtisch_Auszugsfront\",[5746,976,255,588,23,254],\"#758479\"],[\"Bad\",\"Waschtisch_Auszugsfront\",[5746,976,520,588,23,259],\"#758479\"],[\"Bad\",\"Waschtisch\",[5745,992,812,590,395,116],\"#faf9f4\"],[\"Bad\",\"Lavabo_Mulde_Schema\",[5769,1016,928,542,283,2],\"#d7ccbd\"],[\"Bad\",\"Lavabo_Armatur\",[6025,1343,926,30,30,163],\"#727e83\"]]],[\"Bad\",\"WC\",[[\"Bad\",\"WC\",[6782,965,145,355,449,263],\"#faf9f4\"],[\"Bad\",\"WC_Flacher_Deckel\",[6785,974,407,350,443,23],\"#faf9f4\"]]],[\"Einbauten\",\"Eingangsschrank\",[[\"Einbauten\",\"Einbauschrank_Eingang_Korpus\",[3330,200,20,490,880,2340],\"#d8b693\"],[\"Einbauten\",\"Einbauschrank_Eingang_Front\",[3820,210,30,20,427,2330],\"#939e95\"],[\"Einbauten\",\"Einbauschrank_Eingang_Front\",[3820,643,30,20,427,2330],\"#939e95\"]]],[\"Einbauten\",\"Wohnzimmerschrank\",[[\"Einbauten\",\"Einbauschrank_Wohnen_Korpus\",[3850,4200,20,520,1070,2340],\"#d8b693\"],[\"Einbauten\",\"Einbauschrank_Wohnen_Front\",[4370,4210,30,20,520,2330],\"#939e95\"],[\"Einbauten\",\"Einbauschrank_Wohnen_Front\",[4370,4740,30,20,520,2330],\"#939e95\"]]],[\"Einbauten\",\"Garderobe und Schuhablage\",[[\"Einbauten\",\"Garderobe_Hakenleiste\",[5247,2610,1660,30,730,100],\"#b38b5f\"],[\"Einbauten\",\"Garderobe_Haken\",[5198,2690,1694,55,22,18],\"#293234\"],[\"Einbauten\",\"Garderobe_Hakenspitze\",[5198,2690,1702,15,22,29],\"#293234\"],[\"Einbauten\",\"Garderobe_Haken\",[5198,2880,1694,55,22,18],\"#293234\"],[\"Einbauten\",\"Garderobe_Hakenspitze\",[5198,2880,1702,15,22,29],\"#293234\"],[\"Einbauten\",\"Garderobe_Haken\",[5198,3070,1694,55,22,18],\"#293234\"],[\"Einbauten\",\"Garderobe_Hakenspitze\",[5198,3070,1702,15,22,29],\"#293234\"],[\"Einbauten\",\"Garderobe_Haken\",[5198,3260,1694,55,22,18],\"#293234\"],[\"Einbauten\",\"Garderobe_Hakenspitze\",[5198,3260,1702,15,22,29],\"#293234\"],[\"Einbauten\",\"Schuhablage_schwebend\",[5064,2610,260,216,730,26],\"#b38b5f\"],[\"Einbauten\",\"Schuhablage_Wandwinkel\",[5202,2650,217,76,28,50],\"#293234\"],[\"Einbauten\",\"Schuhablage_Wandwinkel\",[5202,3270,217,76,28,50],\"#293234\"],[\"Einbauten\",\"Schuhablage_schwebend\",[5064,2610,410,216,730,26],\"#b38b5f\"],[\"Einbauten\",\"Schuhablage_Wandwinkel\",[5202,2650,367,76,28,50],\"#293234\"],[\"Einbauten\",\"Schuhablage_Wandwinkel\",[5202,3270,367,76,28,50],\"#293234\"]]]]}")
PREFIX = "FW Umbau – "
LAYER = "FW Umbau – Entwurf"
CEILING = "FW Umbau – Decke"


def box(rect):
    x, y, z, width, depth, height = (value * mm for value in rect)
    vs.BeginXtrd(z, z + height)
    vs.Rect(x, -y, x + width, -y - depth)
    vs.EndXtrd()
    vs.ResetOrientation3D()
    obj = vs.LNewObj()
    if not obj or vs.GetTypeN(obj) != 24:
        raise RuntimeError("Der Volumenkörper konnte nicht erstellt werden.")
    return obj


def native_wall(axis, start, end, edge, width, z, height):
    center = (edge + width / 2) * mm
    if axis == "H":
        a, b = (start * mm, -center), (end * mm, -center)
    else:
        a, b = (center, -start * mm), (center, -end * mm)
    vs.Wall(a, b)
    wall = vs.LNewObj()
    if not wall or vs.GetTypeN(wall) != 68:
        raise RuntimeError("Die native Wand konnte nicht erstellt werden.")
    try:
        vs.ConvertToUnstyledWall(wall)
        vs.DeleteAllComponents(wall)
        desired = width * mm
        if not vs.SetWallThickness(wall, desired):
            vs.InsertNewComponent(wall, 1, desired, 1, 5, 5, 1, 1)
        ok, actual = vs.GetWallThickness(wall)
        if not ok or abs(actual - desired) > 0.5 * mm:
            raise RuntimeError("Die Wandstärke konnte nicht gesetzt werden.")
        if not vs.SetWallOverallHeights(wall, 0, 0, "", z * mm, 0, 0, "", (z + height) * mm):
            raise RuntimeError("Die Wandhöhe konnte nicht gesetzt werden.")
        vs.ResetObject(wall)
        return wall
    except Exception:
        vs.DelObject(wall)
        raise


def field_key(name):
    normalized = unicodedata.normalize("NFKD", name.casefold())
    return "".join(c for c in normalized if c.isascii() and c.isalnum())


def fit_opening(obj, opening):
    record = vs.GetParametricRecord(obj)
    if not record:
        return None
    record_name = vs.GetName(record)
    fields = {field_key(name): name for name in (
        vs.GetFldName(record, i) for i in range(1, vs.NumFields(record) + 1)
    )}
    # Overall and RoughOpen are read-only in the standard Window plug-in.
    width = next((fields[key] for key in ("width", "windowwidth", "doorwidth",
                 "rohbaubreite", "breite", "fensterbreite", "turbreite") if key in fields), None)
    height = next((fields[key] for key in ("height", "windowheight", "doorheight",
                  "rohbauhohe", "hohe", "fensterhohe", "turhohe") if key in fields), None)
    if not width or not height:
        return None
    if opening["window"] and "includesill" in fields:
        vs.SetRField(obj, record_name, fields["includesill"], "False")
    for key in ("openangle", "doorswingangle"):
        if key in fields:
            vs.SetRField(obj, record_name, fields[key], "0")

    dimensions = (opening["span"], opening["high"] - opening["low"])
    for field, value in zip((width, height), dimensions):
        vs.SetRField(obj, record_name, field, str(value) + " mm")
    vs.ResetObject(obj)
    for field, size in zip((width, height), dimensions):
        ok, actual = vs.ValidNumStr(vs.GetRField(obj, record_name, field))
        if not ok or abs(actual - size * mm) > 2 * mm:
            return None
    return record_name, width, height


def opening_bounds(obj, horizontal):
    center, z = vs.Get3DCntr(obj)
    dy, dx, dz = vs.Get3DInfo(obj)
    return (center[0] if horizontal else center[1], z,
            abs(dx if horizontal else dy), abs(dz))


def align_opening(obj, wall, opening, horizontal, position, hosted, wall_height, fields):
    center = position[0 if horizontal else 1]
    expected_width = opening["span"] * mm
    expected_height = (opening["high"] - opening["low"]) * mm
    expected_z = opening["low"] * mm + expected_height / 2
    along, z, width, height = opening_bounds(obj, horizontal)
    frame_tolerance = 35 * mm
    if abs(width - expected_width) > frame_tolerance or abs(height - expected_height) > frame_tolerance:
        # Dimension references differ by tool and style (frame / sash / opening).
        # Only correct small measured offsets, never rescale an arbitrary default object.
        delta_width, delta_height = expected_width - width, expected_height - height
        if (not width or not height
                or max(abs(delta_width), abs(delta_height)) > 150 * mm):
            return False
        record_name, width_field, height_field = fields
        vs.SetRField(obj, record_name, width_field, "{:.3f} mm".format((expected_width + delta_width) / mm))
        vs.SetRField(obj, record_name, height_field, "{:.3f} mm".format((expected_height + delta_height) / mm))
        vs.ResetObject(obj)
        along, z, width, height = opening_bounds(obj, horizontal)

    # Correct the measured elevation by a delta; some Window styles already start at 900 mm.
    tolerance = 5 * mm
    dz, shift = expected_z - z, center - along
    if hosted:
        if abs(shift) > frame_tolerance:
            return False
        if abs(dz) > tolerance and not vs.SetObjectWallHeight(obj, wall, wall_height + dz):
            return False
    elif abs(dz) > tolerance or abs(shift) > tolerance:
        vs.Move3DObj(obj, shift if horizontal else 0, 0 if horizontal else shift, dz)
    vs.ResetObject(obj)
    along, z, width, height = opening_bounds(obj, horizontal)
    return (abs(along - center) <= frame_tolerance and abs(z - expected_z) <= tolerance
            and abs(width - expected_width) <= frame_tolerance
            and abs(height - expected_height) <= frame_tolerance)


def place_opening(wall, run, opening):
    names = ("Window", "Window CW", "Fenster CW", "Fenster") if opening["window"] else (
        "Door", "Door CW", "Tür CW", "Tür"
    )
    center = (opening["at"] + opening["span"] / 2) * mm
    transverse = (run["edge"] + run["width"] / 2) * mm
    horizontal = run["axis"] == "H"
    position = (center, -transverse) if horizontal else (transverse, -center)
    vs.NameClass(PREFIX + ("Fenster" if opening["window"] else "Türen"))
    for name in names:
        # The international name remains usable with a localized tool.
        if not vs.GetLocalizedPluginName(name)[0]:
            continue
        obj = vs.CreateCustomObjectN(name, position, 0 if horizontal else -90, False)
        if not obj:
            continue
        fields = fit_opening(obj, opening) if vs.GetTypeN(obj) == 86 else None
        if not fields:
            vs.DelObject(obj)
            continue
        in_host, wall_height = vs.GetObjectWallHeight(obj, wall) if wall else (False, 0)
        parent = vs.GetParent(obj)
        if not in_host and parent and vs.GetTypeN(parent) == 68:
            vs.DelObject(obj)
            continue
        if in_host and not vs.SetObjWallBreakMode(obj, wall, 1):
            vs.DelObject(obj)
            continue
        if not align_opening(obj, wall, opening, horizontal, position, in_host, wall_height, fields):
            vs.DelObject(obj)
            continue
        if in_host and not vs.GetObjectWallHeight(obj, wall)[0]:
            vs.DelObject(obj)
            continue
        vs.SetName(obj, PREFIX + ("Fenster " if opening["window"] else "Tür ") + opening["name"])
        return obj, in_host
    return None, False


def opening_parts(run, opening):
    parts = list(opening["backup"])
    if not opening["window"]:
        at, span, low, high = (opening[k] for k in ("at", "span", "low", "high"))
        transverse = run["edge"] + run["width"] / 2
        rect = (at + 25, transverse - 20, low + 12, span - 50, 40, high - low - 44)
        if run["axis"] == "V":
            rect = (rect[1], rect[0], rect[2], rect[4], rect[3], rect[5])
        parts.append(("Türblatt · schematisch", rect, "#ac8157"))
    return parts


def wall_symbol(wall, run, opening):
    """Use a full wall with a symbol's hidden, dedicated wall-hole component."""
    name = PREFIX + "Wandbauteil " + opening["name"]
    center = opening["at"] + opening["span"] / 2
    transverse = run["edge"] + run["width"] / 2
    low = opening["low"]
    vs.NameClass(PREFIX + ("Fenster" if opening["window"] else "Türen"))
    vs.BeginSym(name)
    try:
        for _, (x, y, z, w, d, h), color in opening_parts(run, opening):
            local = (x - center, y - transverse, z - low, w, d, h)
            if run["axis"] == "V":
                local = (y - center, transverse - x - w, z - low, d, w, h)
            set_color(box(local), color)
    finally:
        vs.EndSym()
    definition = vs.GetObject(name)
    if not definition:
        return False
    vs.SetObjectVariableBoolean(definition, 129, True)  # Insert into walls
    vs.SetObjectVariableInt(definition, 126, 1)         # Full break
    vs.AddSymToWall(wall, (center - run["start"]) * mm, low * mm, False, False, name)
    instance = vs.FIn3D(wall)
    while instance:
        if vs.GetTypeN(instance) == 15 and vs.GetSymName(instance) == name:
            break
        instance = vs.NextObj(instance)
    if not instance:
        return False

    half = opening["span"] / 2
    depth = run["width"] + 20
    height = opening["high"] - low
    bottom = 0 if low else -3
    cutter = box((-half, -depth / 2, bottom, 2 * half, depth, height - bottom))
    tag = PREFIX + "Temporäre Öffnung " + opening["name"]
    vs.SetName(cutter, tag)
    assigned = vs.SetCustomObjectWallHoleGroup(instance, cutter)
    # Depending on version, the API takes ownership or copies the input.
    spare = vs.GetObject(tag)
    if spare and vs.GetParent(spare) == vs.ActLayer():
        vs.DelObject(spare)
    registered = assigned and vs.GetCustomObjectWallHoleGroup(instance)
    if not registered or not vs.SetObjWallBreakMode(instance, wall, 1):
        vs.DelObject(instance)
        return False
    vs.ResetObject(wall)
    return True


def make_run(run):
    name, axis, edge, width = (run[key] for key in ("name", "axis", "edge", "width"))
    wall_class = PREFIX + ("Aussenwände" if name.startswith("AW") else "Innenwände")
    vs.NameClass(wall_class)
    wall = native_wall(axis, run["start"], run["end"], edge, width, 0, run["top"])
    vs.SetName(wall, PREFIX + name)
    results = []
    for opening in run["openings"]:
        obj, hosted = place_opening(wall, run, opening)
        if hosted:
            results.append("hosted")
        else:
            if obj:
                vs.DelObject(obj)
            if not wall_symbol(wall, run, opening):
                break
            results.append("symbol")
    else:
        vs.ResetObject(wall)
        return results, False

    # Compatibility path only, if that Vectorworks version refuses the wall opening.
    # Keep the accurate opening and visible geometry rather than leaving a solid wall.
    vs.DelObject(wall)
    vs.NameClass(wall_class)
    for index, (x, y, z, w, d, h) in enumerate(run["pieces"], 1):
        at, length = (x, w) if axis == "H" else (y, d)
        piece = native_wall(axis, at, at + length, edge, width, z, h)
        vs.SetName(piece, "{}{} / {}".format(PREFIX, name, index))
    for opening in run["openings"]:
        vs.NameClass(PREFIX + ("Fenster" if opening["window"] else "Türen"))
        make_symbol("Ersatz " + opening["name"], opening_parts(run, opening))
    return ["extruded"] * len(run["openings"]), True


def set_color(obj, color):
    if color and len(color) == 7:
        rgb = tuple(int(color[i:i + 2], 16) * 257 for i in (1, 3, 5))
        vs.SetFPat(obj, 1)
        vs.SetFillBack(obj, rgb)


def polygon(points):
    vs.ClosePoly()
    vs.BeginPoly()
    for x, y in points:
        vs.AddPoint(x * mm, -y * mm)
    vs.EndPoly()


def make_slab(name, category, top, points, components):
    vs.NameClass(PREFIX + category)
    polygon(points)
    profile = vs.LNewObj()
    slab = vs.CreateSlab(profile)
    color = components[-1][2] if category == "Decke" else components[0][2]
    if slab and vs.GetTypeN(slab) == 71:
        vs.ConvertToUnstyledSlab(slab)
        vs.DeleteAllComponents(slab)
        for index, (label, thickness, _) in enumerate(components, 1):
            if not vs.InsertNewComponentN(slab, index, thickness * mm, 1, 5, 5, 1, 1):
                vs.DelObject(slab)
                break
            vs.SetComponentName(slab, index, label)
        else:
            vs.SetDatumSlabComponent(slab, 1)
            vs.SetCompDatTopOfComp(slab, 1, True)
            vs.SetSlabHeight(slab, top * mm)
            vs.SetName(slab, PREFIX + name)
            set_color(slab, color)
            vs.ResetObject(slab)
            return True
    else:
        vs.DelObject(profile)
    bottom = top - sum(component[1] for component in components)
    vs.BeginXtrd(bottom * mm, top * mm)
    polygon(points)
    vs.EndXtrd()
    vs.ResetOrientation3D()
    obj = vs.LNewObj()
    vs.SetName(obj, PREFIX + name + " · Ersatzgeometrie")
    set_color(obj, color)
    return False


def make_symbol(name, parts):
    symbol = PREFIX + "Symbol " + name
    x0 = min(rect[0] for _, rect, _ in parts)
    y0 = min(rect[1] for _, rect, _ in parts)
    vs.BeginSym(symbol)
    try:
        for _, (x, y, z, w, d, h), color in parts:
            set_color(box((x - x0, y - y0, z, w, d, h)), color)
    finally:
        vs.EndSym()
    vs.Symbol(symbol, (x0 * mm, -y0 * mm), 0)


def make_lights():
    vs.NameClass(PREFIX + "Beleuchtung")
    for name, x, y, z, kind in PROJECT["lights"]:
        obj = vs.CreateLight(x * mm, -y * mm, z * mm, kind, True, True)
        if obj:
            vs.SetName(obj, PREFIX + name)
            if kind == 2:
                vs.SetLightDirection(obj, 0, -90)


def run_import():
    if vs.GetObject(LAYER) or vs.GetObject(CEILING):
        vs.AlrtDialog("Die Ebene «{}» existiert bereits. Bitte eine neue leere Datei für den erneuten Import verwenden.".format(LAYER))
        return
    global mm
    units_per_inch = vs.GetUnits()[3]
    if not units_per_inch or units_per_inch < 0:
        raise RuntimeError("Die Dokumenteinheiten sind nicht lesbar.")
    mm = units_per_inch / 25.4
    previous_class = vs.ActiveClass()
    vs.Layer(LAYER)
    vs.DoMenuTextByName("Standard Views", 2)
    try:
        results, split_walls = [], []
        for run in PROJECT["walls"]:
            openings, split = make_run(run)
            results.extend(openings)
            if split:
                split_walls.append(run["name"])
        slab_fallback = [slab[0] for slab in PROJECT["slabs"]
                         if slab[1] != "Decke" and not make_slab(*slab)]
        for category, name, parts in PROJECT["symbols"]:
            vs.NameClass(PREFIX + category)
            make_symbol(name, [entry[1:] for entry in parts])
        for index, (category, name, rect, color) in enumerate(PROJECT["solids"], 1):
            vs.NameClass(PREFIX + category)
            obj = box(rect)
            vs.SetName(obj, "{}{:03d} {}".format(PREFIX, index, name.replace("_", " ")))
            set_color(obj, color)
        make_lights()
        vs.Layer(CEILING)
        slab_fallback.extend(slab[0] for slab in PROJECT["slabs"]
                             if slab[1] == "Decke" and not make_slab(*slab))
        vs.Layer(LAYER)
        vs.DoMenuTextByName("Standard Views", 1)
        message = ("FW-Entwurf importiert. Bitte als .vwx speichern. Aufmass erforderlich.\n\n"
                   "Türen und Fenster: {} Werkzeugobjekte, {} Wandsymbole, {} Extrusionsmodelle. "
                   "Türanschläge und Fensterteilung sind Annahmen.").format(
                       results.count("hosted"), results.count("symbol"), results.count("extruded"))
        if split_walls:
            message += "\nWandsegmente als Kompatibilitätslösung: " + ", ".join(split_walls)
        if slab_fallback:
            message += "\nBoden/Decke als Ersatzgeometrie: " + ", ".join(slab_fallback)
        vs.AlrtDialog(message)
    finally:
        vs.NameClass(previous_class)


try:
    run_import()
except Exception as error:
    vs.AlrtDialog("FW-Import unvollständig. Bitte die erzeugte Ebene prüfen.\n" + str(error))
